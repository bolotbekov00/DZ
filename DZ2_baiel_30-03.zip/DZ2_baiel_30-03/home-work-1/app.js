const cities = ['Bishkek', 'Los Angeles', 'Chicago',  'New York', 'Houston', 'Dallas', 'Philadelphia', 'Seattle']
for (let i = 0; i < cities.length; i++){
    if (cities[i].length >9){
        console.log(cities[i])
    }
}